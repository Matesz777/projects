const http = require("http");
const url = require("url");
const fs = require("fs");
const path = require("path");
const formidable = require("formidable");

// Ścieżka do folderu frontend
const baseDir = path.join(__dirname, "..", "frontend");

// Tworzenie folderu na przesłane pliki, jeśli nie istnieje
const uploadDir = path.join(__dirname, "uploaded_files");
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

const mime = {
  ".html": "text/html; charset=utf-8",
  ".css":  "text/css; charset=utf-8",
  ".js":   "application/javascript; charset=utf-8",
  ".png":  "image/png",
  ".jpg":  "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg":  "image/svg+xml",
  ".json": "application/json; charset=utf-8",
  ".pdf":  "application/pdf"
};
http.createServer((req, res) => {
    if(req.url === "/upload" && req.method.toLowerCase() === 'post'){
        let form = new formidable.IncomingForm({
            uploadDir: uploadDir
        });
        form.parse(req, function(err, fields, files){
            if(err){
                res.writeHead(500, {'Content-Type': 'text/plain'});
                res.end("Błąd podczas parsowania formularza: " + err);
                return;
            }
            const uploadedFile = files.file1; 
            if (!uploadedFile) {
                res.writeHead(400, {'Content-Type': 'text/plain'});
                res.end("Brak pliku w formularzu.");
                return;
            }
            let tempPath = uploadedFile.filepath || uploadedFile.name; 
            let newPath = path.join(uploadDir, uploadedFile.originalFilename);

            fs.rename(tempPath, newPath, function(err){
                if(err){
                    res.writeHead(500, {'Content-Type': 'text/plain'});
                    res.end("Błąd podczas zapisywania pliku!");
                } else {
                    res.writeHead(200, {'Content-Type': 'application/json'});
                    res.end(JSON.stringify({path: newPath}));
                }
            });
        });
    } else {
        let pathname = url.parse(req.url, true).pathname;
        if (pathname === "/") pathname = "/index.html";
        
        const filename = path.join(baseDir, pathname);
        const safe = path.normalize(pathname).replace(/^(\.\.[/\\])+/, "");
        const ext = path.extname(filename, safe).toLowerCase();
        
        fs.readFile(filename, (err, data) => {
            if (err) {
                res.writeHead(404, { "Content-Type": "text/html" });
                return res.end("404 - file not found");
            }
            res.writeHead(200, { "Content-Type": mime[ext] });
            res.end(data);
        });
    }
}).listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});