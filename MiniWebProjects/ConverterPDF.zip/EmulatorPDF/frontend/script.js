const localFile = document.getElementById("localFile");
const fileFrame = document.getElementById("file-container");
const addBtn = document.getElementById("addBtn");
const changeBtn = document.getElementById("changeFile");
const filePathDisplay = document.querySelector('.path');

addBtn.addEventListener('click', () => {
    const files = localFile.files;
    const formData = new FormData();
    if (files.length === 0) {
        fileFrame.innerHTML += '<p>Nie wybrano żadnych plików.</p>'
        return;
    }
    fileFrame.innerHTML += '<h2>Wybrane pliki: </h2>'
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        formData.append('file1', file);
        const reader = new FileReader()
        const fileItemDiv = document.createElement('div');
        fileItemDiv.classList.add('file-item');
        fileItemDiv.innerHTML = `<h3>Nazwa pliku: ${file.name}</h3>`
        fileFrame.appendChild(fileItemDiv);
        reader.onload = (e) => {
            const fileContent = e.target.result;
            if (file.type === 'application/pdf') {
                const iframe = document.createElement('iframe');
                iframe.src = fileContent;
                iframe.classList.add('iframe-container')
                fileItemDiv.appendChild(iframe)
            };
            if (i >= 1) {
                const iframe2 = document.createElement('iframe');
                iframe2.src = fileContent;
                iframe2.classList.add('iframe-container-hidden');
                fileItemDiv.appendChild(iframe2);
            };
        };
        reader.readAsDataURL(file);
    };
    fetch('/upload', {
        method: 'POST',
        body: formData
    }).then(response =>{
        if(response.ok){
            console.log('Pliki przesłane pomyślnie');
        }
        else{
            console.error('Błąd podczas przesyłania plików.')
        }
    }).catch(error =>{
        console.error('Błąd sieci: ',error);
    });
    localFile.value = '';
});
let stat = true;
changeBtn.addEventListener('click', () => {
    const fileitem = document.querySelector('.file-item')
    stat = !stat;
    if (stat === true) {
        fileitem.style.display = 'block'
    }
    else {
        fileitem.style.display = 'none'
    }
    changeBtn.textContent = stat ? 'ukryj plik' : 'pokaz plik';
});


