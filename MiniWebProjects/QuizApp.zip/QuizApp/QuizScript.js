const questions = [
    {
        question: "2+2 ?",
        answers: [
            {text: "2", correct: false},
            {text: "3", correct: false},
            {text: "4", correct: true},
            {text: "5", correct: false}
        ]
    },
        {
        question: "2+2*2 ?",
        answers: [
            {text: "8", correct: false},
            {text: "6", correct: true},
            {text: "12", correct: false},
            {text: "2", correct: false}
        ]
    },
        {
        question: "2(2+2) ?",
        answers: [
            {text: "8", correct: true},
            {text: "6", correct: false},
            {text: "14", correct: false},
            {text: "1", correct: false}
        ]
    },
        {
        question: "2+2(2+2*2)/2 ?",
        answers: [
            {text: "14", correct: false},
            {text: "13", correct: false},
            {text: "7", correct: true},
            {text: "9", correct: false}
        ]
    }
];
const questionElement = document.getElementById("question");
const answerBtn = document.getElementById("answer-buttons");
const nextBtn = document.getElementById("nextBtn");

let currentQuestionIndex = 0;
let score = 0;
function startQuiz(){
    currentQuestionIndex = 0;
    score = 0;
    nextBtn.innerHTML = "Next"
    showQuestion();
};

function showQuestion(){
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    let questionNum = currentQuestionIndex + 1;
    questionElement.innerHTML = questionNum + ". " + currentQuestion.question;

    currentQuestion.answers.forEach(answer => {
        const button = document.createElement("button");
        button.innerHTML = answer.text;
        button.classList.add("btn");
        answerBtn.appendChild(button);
        if(answer.correct){
            button.dataset.correct = answer.correct;
        };
        button.addEventListener("click", selectAnswer);
    });
};
function resetState(){
    nextBtn.style.display = "none";
    while(answerBtn.firstChild){
        answerBtn.removeChild(answerBtn.firstChild);
    }
}
function selectAnswer(e){
    const selectedBtn = e.target;
    const isCorrect = selectedBtn.dataset.correct === "true";
    if(isCorrect){
        selectedBtn.classList.add("correct");
        score++;
    }
    else{
        selectedBtn.classList.add("incorrect")
    }
    Array.from(answerBtn.children).forEach(button => {
        if(button.dataset.correct === "true"){
            button.classList.add("correct");
        }
        button.disabled = true;
    });
    nextBtn.style.display = "block"
};
function showScore(){
    resetState();
    questionElement.innerHTML = `You Scored ${score} out of ${questions.length}`
    nextBtn.innerHTML = "Play Again"
    nextBtn.style.display = "block";
};
function handleNextBtn(){
    currentQuestionIndex++;
    if(currentQuestionIndex < questions.length){
        showQuestion();
    }
    else{
        showScore();
    }
};

nextBtn.addEventListener("click", () =>{
    if(currentQuestionIndex < questions.length){
        handleNextBtn();
    }
    else{
        startQuiz();
    }
})
startQuiz();

