const genertedPassword = document.getElementById("generetedpass");
const length = 12;

const randompassword = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+[]{}|;:,.<>?/~`-=";

function createPassword(){
    let password = "";
    for (let i = 0;i < length; i++){
        password += randompassword[Math.floor(Math.random() * randompassword.length)];
    }
    genertedPassword.value = password;
};
function randomcopy(){
    genertedPassword.select();
    document.execCommand("copy");
}



