const api_key = "1d5d7a026a76882b3731f7c1f2ce27e7";
const apiURL = "https://api.openweathermap.org/data/2.5/weather?";
const searchbox = document.querySelector(".search input");
const searchbtn = document.querySelector(".search button");
const weatherIcon = document.querySelector(".weather-icon");

async function checkWeather(city) {
    const respone = await fetch(apiURL + `q=${city}` + `&appid=${api_key}` + `&units=metric`);
    if(respone.status == 404){
        document.querySelector(".error").style.display = "block"
        document.querySelector(".weather").style.display = "none"    
    }
    else{
        var data = await respone.json(city);

        document.querySelector(".city").innerHTML = data.name;
        document.querySelector(".temp").innerHTML = Math.round(data.main.temp) + "°C";
        document.querySelector(".humidity").innerHTML = data.main.humidity + "%";
        document.querySelector(".wind").innerHTML = Math.round(data.wind.speed) + "km/h";

        if(data.weather[0].main == "Clouds"){
            weatherIcon.src = "assets/cloudy.png";
        }
        else if(data.weather[0].main == "Rain"){
            weatherIcon.src = "assets/rain.png";
        }
        else if(data.weather[0].main == "Clear"){
            weatherIcon.src = "assets/Sunny.png";
        }

        document.querySelector(".weather").style.display = "block";
        document.querySelector(".error").style.display = "none"
    }

}

searchbtn.addEventListener("click", () => {
    checkWeather(searchbox.value);
})

